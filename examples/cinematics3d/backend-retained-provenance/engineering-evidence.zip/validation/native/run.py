import json,sys,time,subprocess,unittest
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).parent;repo=Path('/home/complete/.cache/hatch-coordination-20261112/worktrees/cinematics371-retained-config')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head=='c0d4ccf6396a8d566e3d097c8d8094f9e04ede3e',head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
requested=json.loads((root/'queue-request.json').read_text());start=datetime.now(timezone.utc);clock=time.monotonic()
record=dict(code_sha=head,queue_requested_utc=requested['requested_utc'],execution_started_utc=start.isoformat(),queue_wait_seconds=(start-datetime.fromisoformat(requested['requested_utc'])).total_seconds())
print(json.dumps(record),flush=True);sys.path[:0]=[str(repo/'scripts'),str(repo/'tests')]
try:
 from cinematics3d_backend_example import run
 result=run(root/'native','/home/complete/.cache/hatch-fleet/blender-4.5.3-linux-x64/blender')
 print(json.dumps(result,indent=2),flush=True)
 suite=unittest.defaultTestLoader.loadTestsFromNames(['test_rig_cinematics3d_storage.RetainedCinematicPublication','test_render3d_blender.NativeRendering'])
 tested=unittest.TextTestRunner(verbosity=2).run(suite)
 record['native_regressions']=dict(cases=tested.testsRun,skipped=len(tested.skipped),failures=len(tested.failures),errors=len(tested.errors))
 assert tested.wasSuccessful() and tested.testsRun==2 and not tested.skipped,record['native_regressions']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 record['status']='passed'
except BaseException:
 record['status']='failed';raise
finally:
 record.update(execution_finished_utc=datetime.now(timezone.utc).isoformat(),execution_seconds=time.monotonic()-clock)
 (root/'native-timing.json').write_text(json.dumps(record,indent=2)+'\n')

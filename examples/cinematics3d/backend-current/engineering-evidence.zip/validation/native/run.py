import json,sys,time,subprocess
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).parent
repo=Path('/home/complete/.cache/hatch-coordination-20261112/worktrees/cinematics-backend')
expected='840b03bf'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith(expected),head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
requested=json.loads((root/'queue-request.json').read_text())
start=datetime.now(timezone.utc);clock=time.monotonic()
record=dict(code_sha=head,queue_requested_utc=requested['requested_utc'],execution_started_utc=start.isoformat(),queue_wait_seconds=(start-datetime.fromisoformat(requested['requested_utc'])).total_seconds())
print(json.dumps(record),flush=True)
sys.path.insert(0,str(repo/'scripts'))
try:
 from cinematics3d_backend_example import run
 output=run(root/'native','/home/complete/.cache/hatch-fleet/blender-4.5.3-linux-x64/blender')
 record['status']='passed';print(json.dumps(output,indent=2),flush=True)
except BaseException:
 record['status']='failed';raise
finally:
 record.update(execution_finished_utc=datetime.now(timezone.utc).isoformat(),execution_seconds=time.monotonic()-clock)
 (root/'native-timing.json').write_text(json.dumps(record,indent=2)+'\n')
